var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'skumar129',
applicationName: 'myapp',
appUid: 'gQmG7J5wGpdJ0XG4mv',
orgUid: '4HRQ188BWBVwL36P7w',
deploymentUid: 'd781ed5e-30d1-4aaa-b4d4-61d8ae49f674',
serviceName: 'barzbro-api-college',
shouldLogMeta: true,
disableAwsSpans: false,
disableHttpSpans: false,
stageName: 'dev',
pluginVersion: '3.5.0',
disableFrameworksInstrumentation: false})
const handlerWrapperArgs = { functionName: 'barzbro-api-college-dev-get-school-user-time', timeout: 10}
try {
  const userHandler = require('./lambdas/get-school-user-time.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
